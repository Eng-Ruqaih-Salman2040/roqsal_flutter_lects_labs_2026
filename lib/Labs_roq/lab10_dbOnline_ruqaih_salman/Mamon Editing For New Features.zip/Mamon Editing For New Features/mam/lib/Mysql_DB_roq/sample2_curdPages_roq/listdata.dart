import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mam/Mysql_DB_roq/sample2_curdPages_roq/About.dart';
import 'package:mam/Mysql_DB_roq/sample2_curdPages_roq/loginform_simple.dart';
import 'Detail.dart';
import 'adddata.dart';
import 'homepage.dart';

class Home extends StatefulWidget {
  @override
  // final String text;
  // Home({Key key, @required this.text}) : super(key: key);
  _HomeState createState() => new _HomeState();
}

class _HomeState extends State<Home> {

  Future<List> getData() async {
    final http.Response response = await http.get(Uri.parse("http://10.0.2.2/my_store/getdata.php"));
    return json.decode(response.body);
  }
     final _value=false;
  @override
  Widget build(BuildContext context) {
    //TextEditingController _TextEditingController=_TextEditingController();
    return new Scaffold(
      appBar: new AppBar(

        title: new Text(
          "List Data Inventory",
          style: TextStyle(fontFamily: "Netflix"),
        ),
       // backgroundColor: Colors.pink,
        actions: [
          // TextField(
          //   onChanged: (value){
          //     setState(() {
          //       FoodListOnShear =mamon.where
          //         ((element) => element.toLowerCase()
          //           .contains(value.toLowerCase()))
          //           .toList();
          //     });
          //
          //   },
          //  // controller: _TextEditingController,
          //   decoration: InputDecoration(
          //     border: InputBorder.none,
          //     prefixIcon: Icon(
          //       Icons.search,
          //       color: Colors.black,
          //     ),
          //     hintText: "Search for photos",
          //     hintStyle:
          //     TextStyle(color: Colors.grey, fontSize: 15.0),
          //   ),
          // ),

          PopupMenuButton(
            //  color: Colors.yellowAccent,
              elevation: 20,
              enabled: true,
              onSelected: (_value){
                if(_value == true){
                  Navigator.pushNamed(context,'/mamon');
                }
              },
              itemBuilder: (context) => [
                PopupMenuItem(
                  child: Text("Privacy"),
                ),
                PopupMenuItem(
                  child: Text("Settings"),
                ),
                PopupMenuItem(
                  value: true,
                  child: Text("about us"),
                )
              ]
          )
        ],
      ),



       floatingActionButton: Row(

        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[

          FloatingActionButton.extended(

            heroTag: "logout",

            onPressed: () {
              Navigator.of(context).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => new HomePage()));
              // logout(context);

            },
            // onPressed: () => Navigator.of(context).pushReplacement(
            //   new MaterialPageRoute(
            //       builder: (BuildContext context) => new AddData())),
            label: const Text('Menu'),
            icon: const Icon(Icons.logout),
            backgroundColor: Colors.blue,
          ),

          SizedBox(
            width: 20,
          ),

          //SizedBox(height: 10,),
          FloatingActionButton.extended(
            heroTag: "add data",
            onPressed: () {
              Navigator.of(context).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => new AddData()));
            },
            label: const Text('Add Data'),
            icon: const Icon(Icons.add_box),
            backgroundColor: Colors.pink,
          ),


        ],
      ),


      body: Container(

        child:Stack(
          children: [
SizedBox(height: 50),


            FutureBuilder(

              future: getData(),
              builder: (context, snapshot) {
                if (snapshot.hasError) print(snapshot.error);

                return snapshot.hasData
                    ?

                ItemList(

                  list: snapshot.data!,
                )
                    : new Center(
                  child: new CircularProgressIndicator(),
                );
              },
            ),


          ],
        ),
       // color: Colors.amber,
       // child: new
      ),

      // body: new FutureBuilder<List>(
      //   future: getData(),
      //   builder: (context, snapshot) {
      //     if (snapshot.hasError) print(snapshot.error);

      //     return snapshot.hasData
      //         ? new ItemList(
      //             list: snapshot.data,
      //           )
      //         : new Center(
      //             child: new CircularProgressIndicator(),
      //           );
      //   },
      // ),
    );
  }
}

class ItemList extends StatelessWidget {
  final List list;

  ItemList({required this.list});

  @override
  Widget build(BuildContext context) {

    return Center(

      child: new ListView.builder(

        itemCount: list == null ? 0 : list.length,
        itemBuilder: (context, i) {
          return new Container(


            padding: const EdgeInsets.all(10.0),
            child: new GestureDetector(
              onTap: () =>
                  Navigator.of(context).pushReplacement(new MaterialPageRoute(
                      builder: (BuildContext context) => new Detail(
                            list: list,
                            index: i,
                          ))),
              child: new Card(
                child: new ListTile(
                  trailing: Icon(Icons.description),
                  title: new Text(
                    list[i]['item_name'],
                    style: TextStyle(fontFamily: "Netflix"),
                  ),
                  leading: new Icon(Icons.widgets),
                  subtitle: new Text("Stock : ${list[i]['stock']}"),
                ),
              ),
            ),
          );
        },
      ),

    );
  }
}
