import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool themeSwitch = false;

  dynamic themeColors() {
    if (themeSwitch) {
      return Colors.grey[850];
    } else {
      return Colors.greenAccent;
    }
  }


TextEditingController? _TextEditingController= TextEditingController();

  @override
  void dispose(){
    _TextEditingController!.dispose();
    super.dispose();
  }
  List<String> FoodListOnShear=[];

  @override
  Widget build(BuildContext context) {
    //List<String> foodList = ;
    final mamon=List<String>.generate(100,(i)=>
        imageCard("image", "$i").toString() );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: themeColors(),
          elevation: 0,
          brightness: themeSwitch ? Brightness.dark : Brightness.light,
          leading: IconButton(
            onPressed: () {
              setState(() {
                themeSwitch = !themeSwitch;
              });
            },
            icon: themeSwitch
                ? Icon(
              Icons.brightness_3,
              color: themeSwitch ? Colors.greenAccent : Colors.grey[850],
            )
                : Icon(
              Icons.wb_sunny,
              color: themeSwitch ? Colors.greenAccent : Colors.grey[850],
            ),
          ),
        ),
        body: SafeArea(
          child: Container(
            color: themeColors(),
            child: ListView(
              children: <Widget>[
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: themeColors(),
                    borderRadius: BorderRadius.vertical(
                      bottom: Radius.circular(30.0),
                    ),
                  ),
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "unsplassh",
                        style: TextStyle(
                            color: themeSwitch
                                ? Colors.greenAccent
                                : Colors.grey[850],
                            fontSize: 26.0),
                      ),

                      SizedBox(height: 5.0),

                      Text(
                        "Photos for everyone",
                        style: TextStyle(
                          color: themeSwitch
                              ? Colors.greenAccent
                              : Colors.grey[850],
                          fontSize: 40.0,
                        ),
                      ),

                      SizedBox(
                        height: 20.0,
                      ),

                      Container(
                        padding: EdgeInsets.all(5.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        child: TextField(
                          onChanged: (value){
                            setState(() {
                              FoodListOnShear =mamon.where
                                ((element) => element.toLowerCase().contains(value.toLowerCase())).toList();
                            });

                          },
                          controller: _TextEditingController,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            prefixIcon: Icon(
                              Icons.search,
                              color: Colors.black,
                            ),
                            hintText: "Search for photos",
                            hintStyle:
                            TextStyle(color: Colors.grey, fontSize: 15.0),
                          ),
                        ),
                      ),

                      SizedBox(
                        height: 10.0,
                      ),

                    ],
                  ),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Column(
                    children: <Widget>[
                      Text(
                        "Categories",
                        style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold,
                          color: themeSwitch
                              ? Colors.greenAccent
                              : Colors.grey[850],
                        ),
                      ),
                      SizedBox(
                        height: 15.0,
                      ),
                      Container(
                        height: 200.0,
                        child: ListView(

                          scrollDirection: Axis.horizontal,
                          children: <Widget>[
                            imageCard("m", "Landscape"),
                            imageCard("mm", "Architecture"),
                            imageCard("mm", "Animal"),
                            imageCard("m", "Landscape"),
                            imageCard("mm", "Architecture"),
                            imageCard("mm", "Animal"),
                            imageCard("m", "Landscape"),
                            imageCard("mm", "Architecture"),
                            imageCard("mm", "Animal"),

                          ],
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      Container(

                        height: 150,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20.0),
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: AssetImage("images/m.jpg"),

                          ),
                        ),
                        child: Align(
                          alignment: Alignment.bottomLeft,
                          child: Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              "Current Festival",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                       ElevatedButton(
                           onPressed: (){
                             if(Platform.isAndroid){
                               SystemNavigator.pop();
                             }
                             else{
                               exit(0);
                             }
                           }, child: Text("Exit")),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget imageCard(image, title) {
  return AspectRatio(
    aspectRatio: 2.5 / 3,
    child: Container(
      margin: EdgeInsets.only(right: 16.0),
      decoration: BoxDecoration(
        color: Colors.greenAccent,
        borderRadius: BorderRadius.circular(20.0),
        image: DecorationImage(
          fit: BoxFit.cover,
          image: AssetImage("images/$image.jpg"),
        ),
      ),
      child: Align(
        alignment: Alignment.bottomLeft,
        child: Padding(
          padding: EdgeInsets.all(12.0),
          child: Text(
            title,
            style: TextStyle(
                color: Colors.white,
                fontSize: 20.0,
                fontWeight: FontWeight.bold),
          ),
        ),
      ),
    ),
  );
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> foodList = [
    'Orange',
    'Berries',
    'Lemons',
    'Apples',
    'Mangoes',
    'Dates',
    'Avocados',
    'Black Beans',
    'Chickpeas',
    'Pinto beans',
    'White Beans',
    'Green lentils',
    'Split Peas',
    'Rice',
    'Oats',
    'Quinoa',
    'Pasta',
    'Sparkling water',
    'Coconut water',
    'Herbal tea',
    'Kombucha',
    'Almonds',
    'Peannuts',
    'Chia seeds',
    'Flax seeds',
    'Canned tomatoes',
    'Olive oil',
    'Broccoli',
    'Onions',
    'Garlic',
    'Carots',
    'Leafy greens',
    'Meat',
  ];
  List<String>? foodListSearch;
  final FocusNode _textFocusNode = FocusNode();
  TextEditingController? _textEditingController = TextEditingController();
  @override
  void dispose() {
    _textFocusNode.dispose();
    _textEditingController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.blue.shade300,
            title: Container(
              decoration: BoxDecoration(
                  color: Colors.blue.shade200,
                  borderRadius: BorderRadius.circular(20)),
              child: TextField(
                controller: _textEditingController,
                focusNode: _textFocusNode,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    hintText: 'Search here',
                    contentPadding: EdgeInsets.all(8)),
                onChanged: (value) {
                  setState(() {
                    foodListSearch = foodList
                        .where(
                            (element) => element.contains(value.toLowerCase()))
                        .toList();
                    if (_textEditingController!.text.isNotEmpty &&
                        foodListSearch!.length == 0) {
                      print('foodListSearch length ${foodListSearch!.length}');
                    }
                  });
                },
              ),
            )),
        body: _textEditingController!.text.isNotEmpty &&
            foodListSearch!.length == 0
            ? Center(
          child: Padding(
            padding: const EdgeInsets.all(18.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.search_off,
                    size: 160,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'No results found,\nPlease try different keyword',
                    style: TextStyle(
                        fontSize: 30, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        )
            : ListView.builder(
            itemCount: _textEditingController!.text.isNotEmpty
                ? foodListSearch!.length
                : foodList.length,
            itemBuilder: (ctx, index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    CircleAvatar(
                      child: Icon(Icons.food_bank),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(_textEditingController!.text.isNotEmpty
                        ? foodListSearch![index]
                        : foodList[index]),
                  ],
                ),
              );
            }));
  }
}