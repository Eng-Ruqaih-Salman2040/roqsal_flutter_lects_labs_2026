import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mam/Mysql_DB_roq/sample2_curdPages_roq/searsh.dart';
import 'listdata.dart';
import 'loginform.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
void main() {
  runApp(
      about_my_files()
  );
}

class about_my_files extends StatelessWidget {
  const about_my_files({Key? key}) : super(key: key);

  get onPressed => null;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: about()
    );


  }
}

class Update extends StatelessWidget {
  const Update({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return
      Scaffold(

      backgroundColor: Colors.black,
       body :Center(
         child: Column(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [


             SizedBox(

               width: 250,

               child: Column(
                 children: [
                   Card(
                   color: Colors.amber,
                     shape: RoundedRectangleBorder(
                       borderRadius: BorderRadius.all(Radius.circular(100))
                     ),
                     //borderOnForeground: true,
                     //shadowColor:Colors.grey,
                     elevation: 30,
                     child: ListTile(

                      // tileColor: Colors.yellow,
                       //  leading:Image.asset('images/m.jpg'),
                       title: Text('My Files',textAlign: TextAlign.center,style: TextStyle(color: Colors.black),),
                       subtitle: Text('version 10.1.12.541',textAlign: TextAlign.center,),
                       //iconColor: Colors.amber,
                     ),
                   ),

                 ],
               ),


             ),

               Padding(
                 padding:
                 EdgeInsets.only(left: 64, right: 64, top: 16, bottom: 16),
                 child: Text(
                   "Lorem ipsum dolor sit amet,consectetur adipiscing elit,sed do eiusmod tempor incididunt ut labore"
                       "Mamon Fisa Lorem ipsum dolor sit amet,consectetur adipiscing elit,sed do eiusmod "
                       "tempor incididunt ut labore Lorem ipsum dolor sit amet,consectetur"
                       " adipiscing elit,sed do eiusmod tempor"
                       "Lorem ipsum dolor sit amet,consectetur adipiscing elit,sed do eiusmod tempor incididunt ut labore"
                       "Lorem ipsum dolor sit amet,consectetur adipiscing elit,sed do eiusmod"
                       " tempor incididunt ut labore incididunt ut labore Lorem "
                       "ipsum dolor sit amet,consectetur Lorem ipsum dolor sit amet,consectetur "
                       "adipiscing elit,sed do eiusmod tempor incididunt ut labore"
                       "adipiscing elit,sed do eiusmod tempor incididunt ut labore"
                       "Lorem ipsum dolor sit amet,consectetur adipiscing elit,sed"
                       "do eiusmod tempor incididunt ut laboreLorem ipsum dolor sit "
                       "amet,consectetur adipiscing elit,sed do eiusmod tempor incididunt ut labore"
                       "Lorem ipsum dolor sit amet,consectetur adipiscing elit,sed "
                       "do eiusmod tempor incididunt ut laboreLorem ipsum dolor sit amet,consectetur"
                       " adipiscing elit,sed do eiusmod tempor incididunt ut labore"

                       "do eiusmod tempor incididunt ut labore 1",
                   textAlign: TextAlign.center,style: TextStyle(color: Colors.white),
                 ),

               ),

           ],
         ),
       ),
    );
  }
}

class about extends StatelessWidget {
  const about({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Colors.yellow,

      appBar: AppBar(title: Text('About'),
backgroundColor: Colors.amber,
centerTitle: true,
      ),
      backgroundColor: Colors.black,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Container(

              child: Column(
                children: [

                  SizedBox(
                    height: 20,
                  ),
                  Text('My Files',style: TextStyle(color: Colors.white,fontSize: 40),),
                  SizedBox(
                    height: 20,
                  ),
                  Text('version 10.1.12.541',style:TextStyle(color: Colors.grey,fontSize: 15)),
                  SizedBox(
                    height: 15,
                  ),
                  Text('A new version is available',style:TextStyle(color: Colors.grey,fontSize: 15)),
                  SizedBox(
                    height: 20,

                  ),

                  FloatingActionButton.extended(
                    heroTag: "Update",
                    onPressed: () {
                      Navigator.of(context).pushReplacement(new MaterialPageRoute(
                          builder: (BuildContext context) => new MyApp()));
                    },
                    label: const Text('Searsh'),
                    backgroundColor: Colors.amber,
                    // icon: const Icon(Icons.add_box),
                    //backgroundColor: Colors.pink,

                  ),
                  SizedBox(height: 20,),
                  FloatingActionButton.extended(
                    heroTag: "Update",
                    onPressed: () {
                      Navigator.of(context).pushReplacement(new MaterialPageRoute(
                          builder: (BuildContext context) => new HomeScreen()));
                    },
                    label: const Text('Searsh'),
                    backgroundColor: Colors.amber,
                    // icon: const Icon(Icons.add_box),
                    //backgroundColor: Colors.pink,

                  ),
                ],
              ),


            ),
          ),

        ],

      ),


    );
  }
}


class ShareOptionTutorial extends StatelessWidget {
  const ShareOptionTutorial({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Share Option Tutorial"),
      ),
      body: ListView(
        children: [
          myListTile(
            "Flutter Switch",
            "https://www.allaboutflutter.com/post/flutter-switch",
          ),
          myListTile(
            "Gesture Detector in Flutter",
            "https://www.allaboutflutter.com/post/gesture-detector-in-flutter",
          ),
          myListTile("Flutter Dismissible Tutorial",
              "https://www.allaboutflutter.com/post/flutter-dismissible-tutorial"),
          myListTile("GridView Class Tutorial",
              "https://www.allaboutflutter.com/post/gridview-class-tutorial"),
          myListTile(
              "Flutter: SharedPreferences tutorial | How to setup SharedPreferences ?",
              "https://www.allaboutflutter.com/post/flutter-sharedpreferences-tutorial-how-to-setup-sharedpreferences"),
        ],
      ),
    );
  }
}

Widget myListTile(String title, String link) {
  return ListTile(
    title: Text(title),
    minVerticalPadding: 8.0,
    tileColor: Colors.blueAccent,
    trailing: IconButton(
      onPressed: () {
        Share.share("Check out my latest tutorial $link");
      },
      icon: const Icon(Icons.share,color: Colors.lightBlueAccent,),
    ),
  );
}


