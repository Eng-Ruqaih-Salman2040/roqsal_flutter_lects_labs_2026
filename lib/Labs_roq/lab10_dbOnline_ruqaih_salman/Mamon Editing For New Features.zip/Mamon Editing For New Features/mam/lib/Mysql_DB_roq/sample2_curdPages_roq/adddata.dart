import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mam/Mysql_DB_roq/sample2_curdPages_roq/loginform.dart';

import 'dart:async';
import 'dart:convert';

import 'listdata.dart';

class AddData extends StatefulWidget {
  @override
  _AddDataState createState() => new _AddDataState();
}

class _AddDataState extends State<AddData> {
  TextEditingController controllerCode = new TextEditingController();
  TextEditingController controllerName = new TextEditingController();
  TextEditingController controllerPrice = new TextEditingController();
  TextEditingController controllerStock = new TextEditingController();

  void addData() {
    var url = "http://10.0.2.2/my_store/adddata.php";
    http.post(Uri.parse(url), body: {
      "itemcode": controllerCode.text,
      "itemname": controllerName.text,
      "price": controllerPrice.text,
      "stock": controllerStock.text
    });
  }

  void error(BuildContext context, String error) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(
      SnackBar(
        content: Text(error),
        action: SnackBarAction(
            label: 'OK', onPressed: scaffold.hideCurrentSnackBar),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Add Data", style: TextStyle(fontFamily: "Netflix"),),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView(
          children: <Widget>[
            new Column(
              children: <Widget>[
                new TextField(
                  controller: controllerCode,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText: "Item Code",
                      hintStyle: TextStyle(fontFamily: "Netflix"),
                      labelText: "Item Code",
                      labelStyle: TextStyle(fontFamily: "Netflix")),
                ),
                new TextField(
                  controller: controllerName,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText: "Item Name",
                      hintStyle: TextStyle(fontFamily: "Netflix"),
                      labelText: "Item Name"),
                ),
                new TextField(
                  controller: controllerPrice,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText: "Price", labelText: "Price"),
                ),
                new TextField(
                  controller: controllerStock,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText: "Stock", labelText: "Stock"),
                ),
                new Padding(
                  padding: const EdgeInsets.all(10.0),
                ),
                Column(
                  children: <Widget>[
                    Container(
                      height: 50,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          //Navigator.pop(context);
                          Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (context) {
                            return Home();
                          }));
                          // Navigator.of(context).pushReplacement(new MaterialPageRoute(
                          //     builder: (BuildContext context) => new Home()));
                        },
                        child: new Text("Go Home", style: TextStyle(color: Colors.white),),
                        //color: Colors.blueAccent,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      height: 50,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {

                          if (controllerCode.value.text.isEmpty) {
                            setState(() {
                              error(context, "Item Code can not be empty");
                            }); //ID gabole kosong
                          } else if (controllerCode.value.text
                              .contains(RegExp(r'[a-zA-Z]'))) {
                            setState(() {
                              error(context, "Item Code  must be a number");
                              error(context, "Fill in the data correctly!");
                            }); //id harus angka
                          } else if (controllerCode.value.text.length != 3) {
                            setState(() {
                              error(context, "Item Code  must contain 3 digits");
                              error(context, "Fill in the data correctly!");
                            }); //id harus 3 angka
                          } else if (controllerName.value.text.isEmpty) {
                            setState(() {
                              error(context, "Item name can not be empty");
                              error(context, "Fill in the data correctly!");
                            }); //nama ga bole kosong
                          } else if (controllerName.value.text.length < 5) {
                            error(
                                context, "Item name must be at least 5 characters");
                            error(context, "Isi data dengan benar!");
                            //nama gaboleh kurang dari 5
                          } else if (controllerPrice.value.text.isEmpty) {
                            setState(() {
                              error(context, "Price cannot be empty");
                              error(context, "Fill in the data correctly!");
                            }); //harga gabole kosong
                          } else if (controllerPrice.value.text
                              .contains(RegExp(r'[a-zA-Z]'))) {
                            setState(() {
                              error(context, "Fill Price only with numbers");
                              error(context, "Fill in the data correctly!");
                            }); //harga harus angka
                          } else if (controllerPrice.value.text.length < 4) {
                            setState(() {
                              error(context, "The price does not match the format");
                              error(context, "Fill in the data correctly!");
                            }); //harga harus minimal 4 karakter
                          } else {
                            addData();

                            Navigator.pushReplacement(context,MaterialPageRoute(builder: (context) {
                              return showMessage();
                            }
                            ));
                          }

                          // Navigator.of(context).pushReplacement(new MaterialPageRoute(
                          //     builder: (BuildContext context) => new Home()));
                        },
                        child: new Text(
                          "Add Data",
                          style: TextStyle(color: Colors.white),
                        ),
                       style: ElevatedButton.styleFrom(
                           backgroundColor: Colors.pink
                       ),
                      ),
                      
                    )
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            controllerName.clear();
            controllerPrice.clear();
            controllerStock.clear();
            controllerCode.clear();
          });
        },
        child: Text("clear")
      ),
    );
  }
}

class showMessage extends StatelessWidget {
  const showMessage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: AlertDialog(
        title: Text("Data has been added secssfully"),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("OK"))
        ],
      ),
    );
  }
}

class AddUsers extends StatefulWidget {
  @override
  _AddUsersState createState() => new _AddUsersState();
}

class _AddUsersState extends State<AddUsers> {
  TextEditingController controllerUID =  TextEditingController();
  TextEditingController controllerNAME =  TextEditingController();
  TextEditingController controllerUNAME =  TextEditingController();
  TextEditingController controllerUPASS =  TextEditingController();


  void addUsers() {
    var url1 = "http://10.0.2.2/my_store/addusers.php";

    http.post(Uri.parse(url1), body: {
      "UID" :controllerUID.text,
      "NAME" :controllerNAME.text,
      "UNAME": controllerUNAME.text,
      "UPASS": controllerUPASS.text,

    });
  }

  void error(BuildContext context, String error) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(
      SnackBar(
        content: Text(error),
        action: SnackBarAction(
            label: 'OK', onPressed: scaffold.hideCurrentSnackBar),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.indigo,
        centerTitle: true,
        title: new Text("Add Users", style: TextStyle(fontFamily: "Netflix"),),
      ),
      backgroundColor: Colors.lightBlueAccent,
      body: Padding(

        padding: const EdgeInsets.all(20.0),
        child: ListView(
          children: <Widget>[
            new Column(
              children: <Widget>[
                new TextField(
                  controller: controllerUID,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText:"Enter UID" ,
                      hintStyle: TextStyle(fontFamily: "Netflix"),
                      labelText: "ID",
                      labelStyle: TextStyle(fontFamily: "Netflix")),
                ),
                new TextField(
                  controller: controllerNAME,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText:"Enter Name" ,
                      hintStyle: TextStyle(fontFamily: "Netflix"),
                      labelText: "Name",
                      labelStyle: TextStyle(fontFamily: "Netflix")),
                ),
                new TextField(
                  controller: controllerUNAME,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText:"Enter Name User" ,
                      hintStyle: TextStyle(fontFamily: "Netflix"),
                      labelText: "user",
                      labelStyle: TextStyle(fontFamily: "Netflix")),
                ),
                new TextField(
                  controller: controllerUPASS,
                  style: TextStyle(fontFamily: "Netflix", fontSize: 15),
                  decoration: new InputDecoration(
                      hintText: "Enter Password",
                      hintStyle: TextStyle(fontFamily: "Netflix"),
                      labelText:"UPASS" ),
                ),
                Column(
                  children: <Widget>[
                    Container(
                      height: 50,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          //Navigator.pop(context);
                          Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (context) {
                                return LoginForm();
                              }));
                          // Navigator.of(context).pushReplacement(new MaterialPageRoute(
                          //     builder: (BuildContext context) => new Home()));
                        },
                        child: new Text("Go Login", style: TextStyle(color: Colors.white),),
                        //color: Colors.blueAccent,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
                      ),

                    ),
                    SizedBox(
                      height: 20,
                    ),


                    Container(
                      height: 50,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          if (controllerUID.value.text.isEmpty) {
                            setState(() {
                              error(context, "Item name can not be empty");
                            }); //nama ga bole kosong
                          }
                          else if (controllerNAME.value.text.isEmpty) {
                            setState(() {
                              error(context, "Item name can not be empty");
                            }); //nama ga bole kosong
                          }
                          else if (controllerUNAME.value.text.isEmpty) {
                            setState(() {
                              error(context, "Item Code can not be empty");
                            }); //ID gabole kosong
                          }
                          else if (controllerUPASS.value.text.isEmpty) {
                            setState(() {
                              error(context, "Item name can not be empty");
                            }); //nama ga bole kosong
                          }

                          else {
                            setState(() {
                              error(context, "A new user has been added");
                            });
                            addUsers();
                            Navigator.pushReplacement(context,
                                MaterialPageRoute(builder: (context) {

                                  return  LoginForm();

                                }));
                          }

                          // Navigator.of(context).pushReplacement(new MaterialPageRoute(
                          //     builder: (BuildContext context) => new Home()));
                        },
                        child: new Text(
                          "Add Users",
                          style: TextStyle(color: Colors.white),
                        ),

                        style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            setState(() {
              controllerUID.clear();
              controllerNAME.clear();
              controllerUNAME.clear();
              controllerUPASS.clear();
            });
          },
          child: Text("clear"),
        backgroundColor: Colors.indigo,

      ),
    );
  }
}
