import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get_storage/get_storage.dart';
import 'package:mam/Mysql_DB_roq/sample2_curdPages_roq/adddata.dart';
import 'package:mam/Mysql_DB_roq/sample2_curdPages_roq/splash.dart';
import 'package:mam/theme_service.dart';

import 'About.dart';
import 'loginform.dart';


void main() async {
  //await GetStorage.init();
  runApp(CURD_Mysql_sample2_Roq());
}

class CURD_Mysql_sample2_Roq extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(

      theme: ThemeService().lightTheme,
      darkTheme: ThemeService().darkTheme,
      themeMode: ThemeService().getThemeMode(),

      initialRoute: '/',
      routes: {
        '/mamon': (context) => about_my_files(),
        '/m':(context)=>LoginForm(),
        '/n':(context)=>Update(),
        'AddData':(context)=>AddData(),
        //'/Theme':(context)=>changeTheme(),
        '/share':(context)=>ShareOptionTutorial(),

      },
      debugShowCheckedModeBanner: false,
      title: "Inventory Product ",
      // theme: ThemeData(
      //   primarySwatch: Colors.indigo,
      // ),
      home: SplashScreen(),
    );
  }
}
