"""Static integrity check for Lab 2-13 menu.

Usage: python tools/validate_labs_catalog.py
Note: This is not a replacement for `flutter analyze` / `flutter run`.
"""
from collections import Counter
from pathlib import Path
import re
import sys
import yaml
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent.parent
ROUTES = ROOT / 'lib/myApp_MainUI_roq/my_app_routes.dart'
source = ROUTES.read_text(encoding='utf-8-sig')
start = source.index('final List<MyRouteGroup> kMy_LabAppRoutsUI')
end = source.index('const kMy_LectAppRoutsUI')
menu = source[start:end]

all_group_numbers = [int(i) for i in re.findall(r"groupName: 'Lab (\d+) -", menu)]
assert all_group_numbers == list(range(2, 14)), all_group_numbers
aliases = {alias: path for path, alias in re.findall(r"^import '../Labs_roq/([^']+)' as (lab\d+demo\d+);", source, re.M)}
examples = re.findall(
    r'child: (lab\d+demo\d+)\.(\w+)\(\),\s*'
    r"title: '([^']*(?:\\'[^']*)*)',\s*"
    r"description: '([^']*(?:\\'[^']*)*)',\s*"
    r"routeName: '(/labs/\d+/\d+)',\s*"
    r"sourceFilePath: '([^']+)'",
    menu,
)
assert len(examples) >= 12, len(examples)
assert len({e[4] for e in examples}) == len(examples), 'Duplicate route names'
assert len({e[0] for e in examples}) == len(examples), 'Duplicate import aliases'

pub = yaml.safe_load((ROOT / 'pubspec.yaml').read_text(encoding='utf8'))
assets = set(pub['flutter']['assets'])
errors = []
for alias, widget, title, description, route, src in examples:
    imported = aliases.get(alias)
    if imported is None or 'lib/Labs_roq/' + unquote(imported) != src:
        errors.append(f'{route}: wrong imported file')
        continue
    f = ROOT / src
    if not f.is_file():
        errors.append(f'{route}: missing file {src}')
        continue
    content = f.read_text(encoding='utf-8-sig', errors='replace')
    content = re.sub(r'/\*[\s\S]*?\*/', '', content)
    content = re.sub(r'^\s*//.*$', '', content, flags=re.M)
    if not re.search(r'\bclass\s+' + re.escape(widget) + r'\b', content):
        errors.append(f'{route}: missing active class {widget}')
    if src not in assets:
        errors.append(f'{route}: source is not declared as an asset')

# Check import closure, not including external packages.
queue = [ROOT / e[5] for e in examples]
seen = set()
packages = set()
while queue:
    f = queue.pop().resolve()
    if f in seen:
        continue
    seen.add(f)
    if not f.exists():
        errors.append(f'missing local import {f}')
        continue
    text = f.read_text(encoding='utf-8-sig', errors='replace')
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)
    for imp in re.findall(r'^\s*(?:import|export|part)\s+[\'\"]([^\'\"]+)[\'\"]', text, re.M):
        if imp.startswith('dart:') or imp.startswith('package:flutter/'):
            continue
        if imp.startswith('package:roqsal_flutter_lects_labs_2026/'):
            target = ROOT / 'lib' / unquote(imp.split('roqsal_flutter_lects_labs_2026/', 1)[1])
        elif imp.startswith('package:'):
            packages.add(imp.partition(':')[2].partition('/')[0])
            continue
        else:
            target = f.parent / unquote(imp)
        if not target.exists():
            errors.append(f'{f.relative_to(ROOT)}: missing {imp}')
        else:
            queue.append(target)

for pkg in packages:
    if pkg not in pub['dependencies'] and pkg not in pub['dev_dependencies']:
        errors.append(f'package import without a declared dependency: {pkg}')
for asset in assets:
    if not (ROOT / asset).exists():
        errors.append(f'pubspec asset missing: {asset}')

print(f'Lab groups: {len(all_group_numbers)} ({min(all_group_numbers)}–{max(all_group_numbers)})')
print(f'Linked example routes: {len(examples)}')
print(f'Dart files in lab import closure: {len(seen)}')
print(f'Errors: {len(errors)}')
for error in errors:
    print('ERROR:', error)
if errors:
    sys.exit(1)
print('Static catalog integrity: PASS')
