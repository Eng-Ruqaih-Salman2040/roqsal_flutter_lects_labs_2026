# استكمال قائمة Labs من 2 إلى 13 — تحديث نوفمبر 2026

هذا التحديث مبني على الملفات التي أُرفقت في المحادثة، وليس على افتراضات عن محتوى المنهج.

## ما الذي تغير؟

- **12 مجموعة Labs** من Lab 2 حتى Lab 13 داخل `kMy_LabAppRoutsUI`.
- **88 مسارًا** لأمثلة موجودة وأمثلة إضافية، لكل منها `routeName` فريد وعنوان وشرح قصير.
- إمكانية الانتقال إلى الأمثلة من تبويب **Labs** دون تعديل قسم **Lectures** أو سجلاته.
- تحديد مسارات ملفات الشيفرة داخل `sourceFilePath` وإضافتها إلى `pubspec.yaml` لعرض تبويب Source Code.
- إصلاح بعض مسارات `import` القديمة وأسماء ملفات الصور والملفات المرجعية غير الصحيحة.
- تصحيح ربط أزرار التنقل السفلية الستة بالصفحات الست في `home_page.dart`؛ كان يعرض 6 عناصر مقابل 4 صفحات فقط.
- إضافة التبعيات المباشرة للمثال: `http` و`path` و`path_provider` و`uuid`، ونقل `flutter_svg` إلى تبعيات التشغيل.

## تصنيف Labs

| المجموعة | المحتوى | عدد الروابط |
|---|---|---:|
| Lab 2 | Layout Widgets | 5 |
| Lab 3 | Layout Samples | 12 |
| Lab 4 | Input & Material Widgets | 11 |
| Lab 5 | Scaffold Widgets | 4 |
| Lab 6 | Navigation | 15 |
| Lab 7 | Gesture Detector | 8 |
| Lab 8 | Async, Futures & URLs | 5 |
| Lab 9 | SQLite Local Storage | 5 |
| Lab 10 | SQLite Projects & Online API | 4 |
| Lab 11 | State Management Foundations | 3 |
| Lab 12 | Responsive & Adaptive UI | 4 |
| Lab 13 | Provider & GetX State Management | 12 |
| **الإجمالي** | | **88** |

### Lab 11

لم تكن هناك ملفات أو مجلد Lab 11 في الأرشيف المرفوع، لذا أُنشئت ثلاثة أمثلة **إضافية وليست من ملفات المنهج الأصلية**: `setState`، و`ValueNotifier`، و`Provider/ChangeNotifier`. مكانها:
`lib/Labs_roq/lab11_state_management_foundations_roq/lab11_examples_roq.dart`.

### Lab 12

ملفا `login_withResponsive.dart` و`login_withoutResponsive.dart` الأصليان يحتويان على شيفرة معطّلة بالتعليقات. أضفت نسختين مستقلتين للتوضيح (Responsive vs Fixed-width) في `lab12_layout_comparison_roq.dart`. أبقيت الملفات الأصلية دون تغيير لأغراض الرجوع إليها.

### Lab 10 — أمثلة الخادم

أمثلة MySQL/PHP موجودة مسبقًا في المستودع، وتم ربطها بالقائمة **فقط**. تستخدم أمثلة أصلية روابط مثل `http://10.0.2.2/...`، وهو عنوان خاص بمحاكي Android وليس له معنى مباشر على هاتف فعلي. ستحتاج إلى تهيئة خادم وواجهة API صالحة وربط التطبيق بها، ولا يُعد عمل الخادم جزءًا من هذا التحديث.

## كيف تُطبّق التعديل على جهاز Windows؟

**إذا كنت تملك المشروع الكامل على جهازك** (وفيه `android/` و`lib/`):

1. احتفظ بنسخة احتياطية من مشروعك.
2. فك ملف `roqsal_labs_patch_2_to_13.zip` داخل **المجلد الرئيسي للمشروع**، ووافق على استبدال الملفات الموجودة.
3. افتح Terminal داخل المجلد الرئيسي، ونفذ:

```powershell
flutter pub get
flutter analyze
flutter run
```

إذا ظهرت أخطاء جديدة، أرسل المخرجات لنحدد مواقعها. يفضّل وجود مساحة كافية على القرص C قبل تشغيل Gradle؛ مشكلة "There is not enough space on the disk" من سجل المحادثة تُحل بشكل منفصل عن تحديث قائمة اللابات.

**إذا لم يكن لديك المشروع الكامل**: الأرشيف `roqsal_labs_source_2_to_13.zip` يحتوي على ملفات المصدر والأصول (`lib`, `assets_roq`, `pubspec.yaml`) وليس كل بنية Android/iOS؛ انسخها إلى مشروع Flutter كامل بدلًا من محاولة تشغيلها وحدها.

## فحص تم تنفيذه

- فحص YAML الخاص بـ `pubspec.yaml`.
- التحقق من وجود مجموعات Lab 2–13 بالترتيب، 88 مسارًا فريدًا، وجود الأصناف والملفات، وصلاحية الاستيرادات الداخلية الموصولة بهذه المسارات.
- نتيجة الأمر `python tools/validate_labs_catalog.py`: **PASS**.

**حدود الفحص:** لم يتوفر Flutter/Dart SDK في بيئة إعداد هذا التعديل، ولذلك لم يتم تنفيذ `flutter analyze` أو بناء APK أو اختبار الأمثلة تشغيلًا على Android. قد تحتاج بعض الأمثلة الأصلية إلى إصلاحات تشغيلية إضافية، خاصة عند استخدام صور أو خدمات خارجية أو قواعد بيانات، وهذا التحديث لا يزعم أنها جميعًا مجتازة اختبار Android.
